-- phpMyAdmin SQL Dump
-- version 4.0.8
-- http://www.phpmyadmin.net
--
-- Anamakine: localhost
-- Üretim Zamanı: 17 Tem 2014, 05:24:18
-- Sunucu sürümü: 5.5.35-cll
-- PHP Sürümü: 5.3.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Veritabanı: `software_servisci`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `gelenler`
--

CREATE TABLE IF NOT EXISTS `gelenler` (
  `gelen_id` int(11) NOT NULL AUTO_INCREMENT,
  `gelen_adi` text NOT NULL,
  `gelen_soyad` text NOT NULL,
  `gelen_tarih` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gelen_durum` tinyint(4) NOT NULL,
  PRIMARY KEY (`gelen_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `location`
--

CREATE TABLE IF NOT EXISTS `location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_enlem` varchar(100) NOT NULL,
  `location_boylam` varchar(100) NOT NULL,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- Tablo döküm verisi `location`
--

INSERT INTO `location` (`location_id`, `location_enlem`, `location_boylam`) VALUES
(16, '65.9667', '-18.5333'),
(21, '38.74471160558644', '35.38704506955628'),
(22, '38.74349272', '35.48662361'),
(23, '38.74349246', '35.48653331'),
(30, '0.0', '0.0'),
(35, '38.70794491', '35.5250308'),
(36, '0.0', '0.0'),
(37, '65.9667', '-18.5333'),
(38, '65.9667', '-18.5333'),
(39, '65.9667', '-18.5333'),
(40, '65.9667', '-18.5333'),
(41, '65.9667', '-18.5333'),
(42, '38.7017273157835', '35.54069914855063');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `mesajlar`
--

CREATE TABLE IF NOT EXISTS `mesajlar` (
  `mesaj_id` int(11) NOT NULL AUTO_INCREMENT,
  `mesaj_gonderen` int(11) NOT NULL,
  `mesaj_icerik` varchar(400) CHARACTER SET latin1 NOT NULL,
  `mesaj_konu` varchar(400) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`mesaj_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=40 ;

--
-- Tablo döküm verisi `mesajlar`
--

INSERT INTO `mesajlar` (`mesaj_id`, `mesaj_gonderen`, `mesaj_icerik`, `mesaj_konu`) VALUES
(20, 85, 'merhaba suan ki yeni konumunuz nedir?', 'yeni konum'),
(21, 93, 'merhaba yeni konumuzu ogrenebilirmiyim?', 'konum'),
(22, 91, 'Merhaba servisci Bey yeni konumunuz nerededir', 'Merhaba'),
(23, 92, 'Su an nerdesiniz?', 'Nerdesiniz ?'),
(24, 91, 'Saat kac oldu daha gelmediniz acaba birsey mi oldu kac dakikaya burada olursunuz?', 'Gec kaldiniz'),
(25, 95, 'servis nerede', 'servis'),
(27, 85, 'servisci beyefendi nerde kaldiniz su an neredesiniz?', 'daha nerde kaldi '),
(37, 101, 'Merhaba su an nerdesiniz?', 'Konum Bilgisi'),
(38, 101, 'asdasdasd', 'asda'),
(39, 102, 'hzgz', 'hsgz');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `uyeler`
--

CREATE TABLE IF NOT EXISTS `uyeler` (
  `uye_id` int(11) NOT NULL AUTO_INCREMENT,
  `uye_adi` varchar(100) NOT NULL,
  `uye_soyad` varchar(100) NOT NULL,
  `uye_kadi` varchar(200) NOT NULL,
  `uye_sifre` varchar(200) NOT NULL,
  `uye_eposta` varchar(200) NOT NULL,
  PRIMARY KEY (`uye_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=104 ;

--
-- Tablo döküm verisi `uyeler`
--

INSERT INTO `uyeler` (`uye_id`, `uye_adi`, `uye_soyad`, `uye_kadi`, `uye_sifre`, `uye_eposta`) VALUES
(1, 'softwareline.net', 'softwareline.net', 'softwareline.net', 'softwareline', 'bayram_20_03@hotmail.com'),
(86, 'ali', 'veli', 'deli', 'kirkidokuz', 'elli'),
(87, 'eda', 'taskin', 'eda', 'eda', 'sedataskn526@gmail.com'),
(90, 'erciyes', 'erciyes', 'erciyes', 'erciyes', 'erciyes'),
(91, 'Funda', 'Altin', 'funda', 'funda', 'funda'),
(92, 'orhan', 'turkac', 'orhan', 'orhan', 'orhan@gmail.com'),
(93, 'Gizem', 'GONUL', 'gizem', 'gizem', 'gizem@hotmail.com'),
(101, 'kullanici', 'kullanici', 'kullanici', 'kullanici', 'kullanici@gmail.com'),
(102, 'alp', 'alp', 'alp', 'alp', 'alp'),
(103, 'a', 'a', 'a', 'a', 'a@gmail.com');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
